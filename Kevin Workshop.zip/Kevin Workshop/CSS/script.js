let ipTexto = document.querySelector("#ipTexto");
let h2Titulo = document.querySelector("#h2Titulo");
let btTrocarTexto = document.querySelector("#btTrocarTexto");

function TrocarTexto(){
    let texto = ipTexto.value; 
    h2Titulo.textContent = texto;
}

btTrocarTexto.onclick = function(){
    TrocarTexto()
}