
function somarValores(){
    var s1 = document.getElementById("txt1").value;
    var s2 = document.getElementById("txt2").value;
    var s3 = parseInt (s1) + parseInt (s2);
    alert(s3);
}

function dividirValores(){
    var s4 = document.getElementById("s4").value;
    var s5 = document.getElementById("s5").value;
    var s6 = parseInt (s4) - parseInt (s5);
    alert(s6);
}

